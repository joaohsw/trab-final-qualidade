import pytest
from unittest.mock import MagicMock
from truco.jogador import Jogador
from truco.carta import Carta
from truco import envido
from truco import flor

def test_jogador_criacao():
    jogador = Jogador("João")
    assert jogador.nome == "João"
    assert jogador.mao == []

def test_receber_cartas():
    jogador = Jogador("João")
    carta1 = Carta(1, 'Espadas')
    carta2 = Carta(7, 'Ouros')
    carta3 = Carta(3, 'Copas')
    mock_baralho = MagicMock()
    mock_baralho.retirar_carta.side_effect = [carta1, carta2, carta3]
    jogador.criar_mao(mock_baralho)
    assert len(jogador.mao) == 3
    assert str(jogador.mao[0]) == str(carta1)

def test_limpar_mao():
    jogador = Jogador("João")
    jogador.mao = [Carta(1, 'Espadas'), Carta(7, 'Ouros')]
    assert len(jogador.mao) == 2
    jogador.limpar_mao()
    assert len(jogador.mao) == 0

def test_jogar_carta_por_indice():
    jogador = Jogador("João")
    carta1 = Carta(1, 'Espadas')
    carta2 = Carta(7, 'Ouros')
    jogador.mao = [carta1, carta2]
    carta_jogada = jogador.jogar_carta(1)
    assert str(carta_jogada) == str(carta2)
    assert len(jogador.mao) == 1
    assert str(jogador.mao[0]) == str(carta1)

def test_get_pontos_envido(mocker):
    jogador = Jogador("João")
    mocker.patch('truco.envido._get_pontos_envido', return_value=27)
    cartas_envido_27 = [Carta(7, 'Espadas'), Carta(12, 'Espadas'), Carta(1, 'Ouros')]
    jogador.mao = cartas_envido_27
    assert jogador.get_pontos_envido() == 27

def test_tem_flor(mocker):
    jogador = Jogador("João")
    mocker.patch('truco.flor._tem_flor', return_value=True)
    cartas_com_flor = [Carta(1, 'Ouros'), Carta(7, 'Ouros'), Carta(5, 'Ouros')]
    jogador.mao = cartas_com_flor
    assert jogador.tem_flor() is True

def test_get_pontos_flor(mocker):
    jogador = Jogador("João")
    mocker.patch('truco.flor._get_pontos_flor', return_value=32)
    cartas_flor_32 = [Carta(5, 'Ouros'), Carta(7, 'Ouros'), Carta(12, 'Ouros')]
    jogador.mao = cartas_flor_32
    assert jogador.get_pontos_flor() == 32

def test_cantar_acoes_simples():
    jogador = Jogador("João")
    assert jogador.aceitar() == 'ACEITO'
    assert jogador.nao_aceitar() == 'NAO ACEITO'
    assert jogador.cantar_flor() == 'FLOR'